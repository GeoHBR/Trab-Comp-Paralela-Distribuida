/**
 * 
 */
/**
 * 
 */
module Trabalho {
    requires java.desktop;

}